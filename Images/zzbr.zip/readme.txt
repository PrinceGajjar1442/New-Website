﻿=== ZZBR Cursor Set ===

By: RIDDLER (http://www.rw-designer.com/user/70600)

Download: http://www.rw-designer.com/cursor-set/zzbr

Author's description:

I have spend a whole day creating the "ZZBR" cursor set. This whole set has a white outline and a black interior for each of the cursors. There are a total of 15 cursors for this set.

Please note that the white outline is only visible on colored backgrounds. On a black background, it would make the cursors appear as they have a very thick outline.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.